﻿
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace TAREA.Models
{
    public partial class Puesto
    {
        public int IdPuesto { get; set; }

        public string? Nombre { get; set; }

        [JsonIgnore]
        public virtual ICollection<Empleado> Empleados { get; set; } = new List<Empleado>();
    }
}
